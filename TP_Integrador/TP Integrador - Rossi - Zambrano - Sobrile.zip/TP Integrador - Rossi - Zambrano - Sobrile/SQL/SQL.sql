--1)
SELECT alu.nombreal   AS Nombre,
       car.nombrecarr AS Carrera,
       mat.nombremat  AS Materia,
       nota.calif     AS Calificaci�n,
       nota.fecha     AS Fecha
FROM tp1.alumno AS alu
	INNER JOIN tp1.monitor AS mon
		ON alu.codigoal = mon.codigoal
	INNER JOIN tp1.materia mat
		ON mon.codmat = mat.codmat
        AND mat.codmat = mon.codmat
    INNER JOIN tp1.carrera AS car
        ON mat.carrera = car.codcarr
    INNER JOIN tp1.nota AS nota
        ON alu.codigoal = nota.codigoal
        AND mat.codmat = nota.codmat
ORDER BY alu.nombreal, car.nombrecarr, mat.nombremat;
--
--
--2)
SELECT alu.nombreal AS Nombre, car.nombrecarr AS Carrera, mat.nombremat AS Materia, AVG(nota.calif) as Promedio, MAX(fecha) as Fecha
FROM tp1.alumno AS alu
	INNER JOIN tp1.monitor AS mon
		ON alu.codigoal = mon.codigoal
	INNER JOIN tp1.materia mat
		ON mon.codmat = mat.codmat
		AND mat.codmat = mon.codmat
	INNER JOIN tp1.carrera AS car
		ON mat.carrera = car.codcarr
	INNER JOIN tp1.nota AS nota
		ON alu.codigoal = nota.codigoal
		AND mat.codmat = nota.codmat
GROUP BY alu.nombreal, car.nombrecarr, mat.nombremat
ORDER BY alu.nombreal,  car.nombrecarr, mat.nombremat;
--
--
--3)
SELECT carr.nombrecarr AS Carrera, AVG(nota.calif) AS Promedio, alu.nombreal AS Nombre
FROM tp1.alumno alu
	INNER JOIN tp1.nota
		ON alu.codigoal = nota.codigoal
	INNER JOIN tp1.carrera carr
		ON alu.carrera  = carr.codcarr
GROUP BY alu.nombreal, carr.nombrecarr
HAVING AVG(nota.calif) IN ( SELECT MAX(PromXCarrera)
							FROM ( SELECT mat.carrera, AVG(nota.calif) AS PromXCarrera, nota.codigoal
									FROM tp1.nota
									INNER JOIN tp1.materia mat
									ON nota.codmat = mat.codmat
									GROUP BY mat.carrera, nota.codigoal)p
							GROUP BY p.carrera
						   );
--
--
--4)
SELECT car.codcarr AS Carrera, car.nombrecarr, COUNT(alu.codigoal) Cant_Alumnos
FROM tp1.carrera AS car
	INNER JOIN tp1.alumno AS alu
		ON car.codcarr = alu.carrera
GROUP BY car.codcarr, car.nombrecarr
ORDER BY COUNT(alu.codigoal) DESC;
--
--
--5)
SELECT mat.nombrecarr AS Carrera, mat.nombremat AS Materia, mat.Desaprobados 'Cantidad Desaprobados' 
FROM (SELECT TOP 3 COUNT(nota.codmat) AS Desaprobados, materia.nombremat, carrera.nombrecarr 
	  FROM tp1.nota 
		INNER JOIN tp1.materia 
			ON nota.codmat = materia.codmat
		INNER JOIN tp1.carrera
			ON carrera.codcarr = materia.carrera
	  WHERE nota.calif < 4
	  GROUP BY nota.codmat,materia.nombremat, carrera.nombrecarr)mat
ORDER BY mat.Desaprobados DESC;